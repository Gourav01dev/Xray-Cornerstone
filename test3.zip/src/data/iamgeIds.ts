// https://github.com/ChienChihYeh/example-dicom

import img from '../assets/image-000001.dcm';
const startIndex = 1;

const padNumber = (num: number, size: number, prefix: string) => {
  return num.toString().padStart(size, prefix);
};

export const imageIds = Array(360)
  .fill(0)
  .map((_, i) => {
    const paddedIndex = padNumber(startIndex + i, 6, "0");
    console.log('cheking image', paddedIndex);
    
    return `wadouri:https://raw.githubusercontent.com/ChienChihYeh/example-dicom/main/image-${paddedIndex}.dcm`;
  });
